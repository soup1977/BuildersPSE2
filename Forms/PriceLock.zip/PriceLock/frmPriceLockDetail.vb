﻿' =====================================================
' frmPriceLockDetail.vb
' Main Price Lock editing form with Component and Material tabs
' ENHANCED: Margin propagation and price update prompts
' BuildersPSE2 - PriceLock Module
' =====================================================

Option Strict On
Option Explicit On

Imports System.Windows.Forms
Imports System.Drawing
Imports System.Linq
Imports BuildersPSE2.DataAccess
Imports BuildersPSE2.Models

Public Class frmPriceLockDetail

#Region "Fields"

    Private _dataAccess As PriceLockDataAccess
    Private _priceLock As PLPriceLock
    Private _componentPricing As List(Of PLComponentPricing)
    Private _materialPricing As List(Of PLMaterialPricing)
    Private _isDirty As Boolean = False

    ' Track original margin values for change detection
    Private _originalAdjustedMargin As Decimal
    Private _originalOptionMargin As Decimal

#End Region

#Region "Constructor"

    Public Sub New(priceLock As PLPriceLock, dataAccess As PriceLockDataAccess)
        _priceLock = priceLock
        _dataAccess = dataAccess
        InitializeComponent()

        ' Setup grids before loading data
        SetupComponentGrid()
        SetupMaterialGrid()

        ' Populate status combo
        cboStatus.Items.AddRange(New String() {
            PLPriceLockStatus.Draft,
            PLPriceLockStatus.Pending,
            PLPriceLockStatus.Approved,
            PLPriceLockStatus.Sent
        })

        ' Wire up event handlers for value changes
        AddHandler dtpLockDate.ValueChanged, AddressOf Control_ValueChanged
        AddHandler txtLockName.TextChanged, AddressOf Control_ValueChanged
        AddHandler nudBaseMgmtMargin.ValueChanged, AddressOf Control_ValueChanged
        ' ENHANCED: Special handlers for margin changes
        AddHandler nudAdjustedMargin.ValueChanged, AddressOf AdjustedMargin_ValueChanged
        AddHandler nudOptionMargin.ValueChanged, AddressOf OptionMargin_ValueChanged
    End Sub

#End Region

#Region "Form Events"

    Private Sub frmPriceLockDetail_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadPriceLockData()

        ' Store original margin values
        _originalAdjustedMargin = nudAdjustedMargin.Value
        _originalOptionMargin = nudOptionMargin.Value

        LoadComponentPricing()
        LoadMaterialPricing()
        UpdateControlStates()
        _isDirty = False
    End Sub

    Private Sub frmPriceLockDetail_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        If _isDirty Then
            Dim result = MessageBox.Show("You have unsaved changes. Do you want to save before closing?",
                "Unsaved Changes", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)

            If result = DialogResult.Yes Then
                SavePriceLock()
            ElseIf result = DialogResult.Cancel Then
                e.Cancel = True
            End If
        End If
    End Sub

    Private Sub Control_ValueChanged(sender As Object, e As EventArgs)
        _isDirty = True
    End Sub
    ' ENHANCED: Handle adjusted margin changes with propagation
    Private Sub AdjustedMargin_ValueChanged(sender As Object, e As EventArgs)
        _isDirty = True

        ' Check if this is a meaningful change (not just loading)
        If _componentPricing Is Nothing OrElse _componentPricing.Count = 0 Then Return
        If nudAdjustedMargin.Value = _originalAdjustedMargin Then Return

        ' Prompt user to update related records
        Dim affected = Enumerable.Count(_componentPricing, Function(c) Not c.UsesOptionMargin)
        If affected > 0 Then
            Dim msg = $"The Adjusted Margin has changed from {_originalAdjustedMargin:P1} to {nudAdjustedMargin.Value:P1}." & vbCrLf & vbCrLf &
                      $"This affects {affected} component pricing record(s) (base models and non-option elevations)." & vbCrLf & vbCrLf &
                      "Do you want to recalculate prices for these records now?"

            Dim result = MessageBox.Show(msg, "Update Prices?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            If result = DialogResult.Yes Then
                UpdatePricesForMarginChange("Adjusted", nudAdjustedMargin.Value)
                _originalAdjustedMargin = nudAdjustedMargin.Value
            End If
        End If
    End Sub

    ' ENHANCED: Handle option margin changes with propagation
    Private Sub OptionMargin_ValueChanged(sender As Object, e As EventArgs)
        _isDirty = True

        ' Check if this is a meaningful change (not just loading)
        If _componentPricing Is Nothing OrElse _componentPricing.Count = 0 Then Return
        If nudOptionMargin.Value = _originalOptionMargin Then Return

        ' Prompt user to update related records
        Dim affected = Enumerable.Count(_componentPricing, Function(c) c.UsesOptionMargin)
        If affected > 0 Then
            Dim msg = $"The Option Margin has changed from {_originalOptionMargin:P1} to {nudOptionMargin.Value:P1}." & vbCrLf & vbCrLf &
                      $"This affects {affected} component pricing record(s) (options and option-based elevations)." & vbCrLf & vbCrLf &
                      "Do you want to recalculate prices for these records now?"

            Dim result = MessageBox.Show(msg, "Update Prices?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            If result = DialogResult.Yes Then
                UpdatePricesForMarginChange("Option", nudOptionMargin.Value)
                _originalOptionMargin = nudOptionMargin.Value
            End If
        End If
    End Sub

#End Region

#Region "Grid Setup"

    Private Sub SetupComponentGrid()
        dgvComponents.AutoGenerateColumns = False
        dgvComponents.Columns.Clear()

        ' Add columns explicitly
        dgvComponents.Columns.Add(New DataGridViewTextBoxColumn() With {
            .Name = "ComponentPricingID",
            .HeaderText = "ID",
            .DataPropertyName = "ComponentPricingID",
            .Visible = False
        })

        dgvComponents.Columns.Add(New DataGridViewTextBoxColumn() With {
            .Name = "PlanName",
            .HeaderText = "Plan",
            .DataPropertyName = "PlanName",
            .Width = 100,
            .ReadOnly = True
        })

        dgvComponents.Columns.Add(New DataGridViewTextBoxColumn() With {
            .Name = "ElevationName",
            .HeaderText = "Elevation",
            .DataPropertyName = "ElevationName",
            .Width = 100,
            .ReadOnly = True
        })

        dgvComponents.Columns.Add(New DataGridViewTextBoxColumn() With {
            .Name = "OptionName",
            .HeaderText = "Option",
            .DataPropertyName = "OptionName",
            .Width = 150,
            .ReadOnly = True
        })

        dgvComponents.Columns.Add(New DataGridViewTextBoxColumn() With {
            .Name = "ProductTypeName",
            .HeaderText = "Type",
            .DataPropertyName = "ProductTypeName",
            .Width = 80,
            .ReadOnly = True
        })

        ' ENHANCED: Add Margin Source column
        dgvComponents.Columns.Add(New DataGridViewTextBoxColumn() With {
            .Name = "MarginName",
            .HeaderText = "Margin",
            .DataPropertyName = "MarginName",
            .Width = 75,
            .ReadOnly = True
        })

        dgvComponents.Columns.Add(New DataGridViewTextBoxColumn() With {
            .Name = "Cost",
            .HeaderText = "Cost",
            .DataPropertyName = "Cost",
            .Width = 100,
            .ReadOnly = True,
            .DefaultCellStyle = New DataGridViewCellStyle() With {
                .Format = "C2",
                .Alignment = DataGridViewContentAlignment.MiddleRight
            }
        })

        dgvComponents.Columns.Add(New DataGridViewTextBoxColumn() With {
            .Name = "MgmtSellPrice",
            .HeaderText = "Mgmt Sell",
            .DataPropertyName = "MgmtSellPrice",
            .Width = 100,
            .ReadOnly = True,
            .DefaultCellStyle = New DataGridViewCellStyle() With {
                .Format = "C2",
                .Alignment = DataGridViewContentAlignment.MiddleRight
            }
        })

        dgvComponents.Columns.Add(New DataGridViewTextBoxColumn() With {
            .Name = "FinalPrice",
            .HeaderText = "Final Price",
            .DataPropertyName = "FinalPrice",
            .Width = 100,
            .ReadOnly = True,
            .DefaultCellStyle = New DataGridViewCellStyle() With {
                .Format = "C2",
                .Alignment = DataGridViewContentAlignment.MiddleRight
            }
        })

        dgvComponents.Columns.Add(New DataGridViewTextBoxColumn() With {
            .Name = "PriceSentToBuilder",
            .HeaderText = "Builder Price",
            .DataPropertyName = "PriceSentToBuilder",
            .Width = 100,
            .ReadOnly = True,
            .DefaultCellStyle = New DataGridViewCellStyle() With {
                .Format = "C2",
                .Alignment = DataGridViewContentAlignment.MiddleRight
            }
        })

        ' Use a TextBox column for IsAdder (will be formatted in CellFormatting)
        dgvComponents.Columns.Add(New DataGridViewTextBoxColumn() With {
            .Name = "IsAdder",
            .HeaderText = "Adder",
            .DataPropertyName = "IsAdder",
            .Width = 60,
            .ReadOnly = True
        })

        ' Warning icon column
        dgvComponents.Columns.Add(New DataGridViewTextBoxColumn() With {
            .Name = "HasDiff",
            .HeaderText = "⚠",
            .Width = 30,
            .ReadOnly = True
        })

        dgvComponents.Columns.Add(New DataGridViewTextBoxColumn() With {
            .Name = "PriceNote",
            .HeaderText = "Notes",
            .DataPropertyName = "PriceNote",
            .Width = 150,
            .ReadOnly = True
        })

        dgvComponents.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvComponents.MultiSelect = False
        dgvComponents.AllowUserToAddRows = False
        dgvComponents.AllowUserToDeleteRows = False
    End Sub

    Private Sub SetupMaterialGrid()
        dgvMaterials.AutoGenerateColumns = False
        dgvMaterials.Columns.Clear()

        ' Add columns explicitly
        dgvMaterials.Columns.Add(New DataGridViewTextBoxColumn() With {
            .Name = "MaterialPricingID",
            .HeaderText = "ID",
            .DataPropertyName = "MaterialPricingID",
            .Visible = False
        })

        dgvMaterials.Columns.Add(New DataGridViewTextBoxColumn() With {
            .Name = "CategoryName",
            .HeaderText = "Category",
            .DataPropertyName = "CategoryName",
            .Width = 150,
            .ReadOnly = True
        })

        dgvMaterials.Columns.Add(New DataGridViewTextBoxColumn() With {
            .Name = "CategoryCode",
            .HeaderText = "Code",
            .DataPropertyName = "CategoryCode",
            .Width = 80,
            .ReadOnly = True
        })

        dgvMaterials.Columns.Add(New DataGridViewTextBoxColumn() With {
            .Name = "RandomLengthsPrice",
            .HeaderText = "RL Price",
            .DataPropertyName = "RandomLengthsPrice",
            .Width = 100,
            .ReadOnly = True,
            .DefaultCellStyle = New DataGridViewCellStyle() With {
                .Format = "C2",
                .Alignment = DataGridViewContentAlignment.MiddleRight
            }
        })

        dgvMaterials.Columns.Add(New DataGridViewTextBoxColumn() With {
            .Name = "CalculatedPrice",
            .HeaderText = "Calc Price",
            .DataPropertyName = "CalculatedPrice",
            .Width = 100,
            .ReadOnly = True,
            .DefaultCellStyle = New DataGridViewCellStyle() With {
                .Format = "C2",
                .Alignment = DataGridViewContentAlignment.MiddleRight
            }
        })

        dgvMaterials.Columns.Add(New DataGridViewTextBoxColumn() With {
            .Name = "PriceSentToBuilder",
            .HeaderText = "Builder Price",
            .DataPropertyName = "PriceSentToBuilder",
            .Width = 100,
            .ReadOnly = True,
            .DefaultCellStyle = New DataGridViewCellStyle() With {
                .Format = "C2",
                .Alignment = DataGridViewContentAlignment.MiddleRight
            }
        })

        dgvMaterials.Columns.Add(New DataGridViewTextBoxColumn() With {
            .Name = "PctChangeFromPrevious",
            .HeaderText = "% Change",
            .DataPropertyName = "PctChangeFromPrevious",
            .Width = 80,
            .ReadOnly = True,
            .DefaultCellStyle = New DataGridViewCellStyle() With {
                .Format = "P1",
                .Alignment = DataGridViewContentAlignment.MiddleRight
            }
        })

        ' Warning icon column
        dgvMaterials.Columns.Add(New DataGridViewTextBoxColumn() With {
            .Name = "HasDiffMat",
            .HeaderText = "⚠",
            .Width = 30,
            .ReadOnly = True
        })

        dgvMaterials.Columns.Add(New DataGridViewTextBoxColumn() With {
            .Name = "PriceNote",
            .HeaderText = "Notes",
            .DataPropertyName = "PriceNote",
            .Width = 150,
            .ReadOnly = True
        })

        dgvMaterials.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvMaterials.MultiSelect = False
        dgvMaterials.AllowUserToAddRows = False
        dgvMaterials.AllowUserToDeleteRows = False
    End Sub

#End Region

#Region "Button Events"

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        SavePriceLock()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnChangeStatus_Click(sender As Object, e As EventArgs) Handles btnChangeStatus.Click
        ChangeStatus()
    End Sub

    Private Sub btnAddComponent_Click(sender As Object, e As EventArgs) Handles btnAddComponent.Click
        AddComponent()
    End Sub

    Private Sub btnEditComponent_Click(sender As Object, e As EventArgs) Handles btnEditComponent.Click
        EditSelectedComponent()
    End Sub

    Private Sub btnDeleteComponent_Click(sender As Object, e As EventArgs) Handles btnDeleteComponent.Click
        DeleteSelectedComponent()
    End Sub

    Private Sub btnImportMitek_Click(sender As Object, e As EventArgs) Handles btnImportMitek.Click
        ImportMitekCsv()
    End Sub

    Private Sub btnEditMaterial_Click(sender As Object, e As EventArgs) Handles btnEditMaterial.Click
        EditSelectedMaterial()
    End Sub

    ' ADD this button event handler in the "Button Events" region (around line 433)

    Private Sub btnAddMaterial_Click(sender As Object, e As EventArgs) Handles btnAddMaterial.Click
        AddMaterial()
    End Sub

    Private Sub btnImportRL_Click(sender As Object, e As EventArgs) Handles btnImportRL.Click
        ImportRandomLengths()
    End Sub

#End Region

#Region "Grid Events"

    Private Sub dgvComponents_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvComponents.CellDoubleClick
        If e.RowIndex >= 0 Then
            EditSelectedComponent()
        End If
    End Sub

    Private Sub dgvComponents_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles dgvComponents.CellFormatting
        If e.RowIndex < 0 OrElse e.RowIndex >= _componentPricing.Count Then Return

        Dim comp = _componentPricing(e.RowIndex)

        ' Show warning icon if prices differ
        If dgvComponents.Columns(e.ColumnIndex).Name = "HasDiff" Then
            e.Value = If(comp.HasPriceDifference, "⚠", "")
            e.FormattingApplied = True
        End If

        ' Format IsAdder column as Yes/No instead of True/False
        If dgvComponents.Columns(e.ColumnIndex).Name = "IsAdder" AndAlso e.Value IsNot Nothing Then
            If TypeOf e.Value Is Boolean Then
                e.Value = If(CBool(e.Value), "Yes", "No")
                e.FormattingApplied = True
            End If
        End If

        ' ENHANCED: Color-code margin source
        If dgvComponents.Columns(e.ColumnIndex).Name = "MarginSource" Then
            If comp.UsesOptionMargin Then
                e.CellStyle.ForeColor = Color.DarkBlue
                e.CellStyle.Font = New Font(e.CellStyle.Font, FontStyle.Bold)
            End If
        End If

        ' Highlight rows with price differences
        If comp.HasPriceDifference Then
            dgvComponents.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.LightYellow
        End If
    End Sub

    Private Sub dgvMaterials_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvMaterials.CellDoubleClick
        If e.RowIndex >= 0 Then
            EditSelectedMaterial()
        End If
    End Sub

    Private Sub dgvMaterials_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles dgvMaterials.CellFormatting
        If e.RowIndex < 0 OrElse e.RowIndex >= _materialPricing.Count Then Return

        Dim mat = _materialPricing(e.RowIndex)

        ' Show warning icon if prices differ
        If dgvMaterials.Columns(e.ColumnIndex).Name = "HasDiffMat" Then
            e.Value = If(mat.HasPriceDifference, "⚠", "")
            e.FormattingApplied = True
        End If

        ' Highlight rows with price differences
        If mat.HasPriceDifference Then
            dgvMaterials.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.LightYellow
        End If

        ' Color code percent change
        If dgvMaterials.Columns(e.ColumnIndex).Name = "PctChangeFromPrevious" AndAlso mat.PctChangeFromPrevious.HasValue Then
            If mat.PctChangeFromPrevious.Value > 0.05D Then
                e.CellStyle.ForeColor = Color.Red
            ElseIf mat.PctChangeFromPrevious.Value < -0.05D Then
                e.CellStyle.ForeColor = Color.Green
            End If
        End If
    End Sub

#End Region

#Region "Data Loading"

    Private Sub LoadPriceLockData()
        lblBuilderValue.Text = _priceLock.BuilderName
        lblSubdivisionValue.Text = _priceLock.SubdivisionName
        lblCodeValue.Text = If(_priceLock.SubdivisionCode, "--")
        dtpLockDate.Value = _priceLock.PriceLockDate
        txtLockName.Text = _priceLock.PriceLockName
        cboStatus.Text = _priceLock.Status
        nudBaseMgmtMargin.Value = If(_priceLock.BaseMgmtMargin, CDec(0.15))
        nudAdjustedMargin.Value = If(_priceLock.AdjustedMarginBaseModels, CDec(0.15))
        nudOptionMargin.Value = If(_priceLock.OptionMargin, CDec(0.3))
    End Sub

    Private Sub LoadComponentPricing()
        _componentPricing = _dataAccess.GetComponentPricingByLock(_priceLock.PriceLockID)
        dgvComponents.DataSource = Nothing
        dgvComponents.DataSource = _componentPricing
    End Sub

    Private Sub LoadMaterialPricing()
        _materialPricing = _dataAccess.GetMaterialPricingByLock(_priceLock.PriceLockID)
        dgvMaterials.DataSource = Nothing
        dgvMaterials.DataSource = _materialPricing
    End Sub

#End Region

#Region "CRUD Operations"

    Private Sub SavePriceLock()
        Try
            Cursor = Cursors.WaitCursor

            _priceLock.PriceLockDate = dtpLockDate.Value.Date
            _priceLock.PriceLockName = txtLockName.Text.Trim()
            _priceLock.BaseMgmtMargin = nudBaseMgmtMargin.Value
            _priceLock.AdjustedMarginBaseModels = nudAdjustedMargin.Value
            _priceLock.OptionMargin = nudOptionMargin.Value

            _dataAccess.UpdatePriceLock(_priceLock)

            ' Update original values after save
            _originalAdjustedMargin = nudAdjustedMargin.Value
            _originalOptionMargin = nudOptionMargin.Value

            _isDirty = False
            MessageBox.Show("Price lock saved successfully.", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show($"Error saving price lock: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            Cursor = Cursors.Default
        End Try
    End Sub

    ' ENHANCED: Update prices when margin changes
    Private Sub UpdatePricesForMarginChange(marginType As String, newMargin As Decimal)
        Try
            Cursor = Cursors.WaitCursor

            _dataAccess.RecalculatePricesForMarginChange(_priceLock.PriceLockID, marginType, newMargin, Environment.UserName)

            ' Reload the grid to show updated prices
            LoadComponentPricing()

            MessageBox.Show($"Prices updated for {marginType} margin records.", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show($"Error updating prices: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            Cursor = Cursors.Default
        End Try
    End Sub

    Private Sub ChangeStatus()
        Dim currentStatus = _priceLock.Status
        Dim newStatus As String = Nothing

        ' Determine next status
        Select Case currentStatus
            Case PLPriceLockStatus.Draft
                newStatus = PLPriceLockStatus.Pending
            Case PLPriceLockStatus.Pending
                If MessageBox.Show("Approve this price lock?", "Confirm", MessageBoxButtons.YesNo) = DialogResult.Yes Then
                    newStatus = PLPriceLockStatus.Approved
                End If
            Case PLPriceLockStatus.Approved
                If MessageBox.Show("Mark as sent to builder?", "Confirm", MessageBoxButtons.YesNo) = DialogResult.Yes Then
                    newStatus = PLPriceLockStatus.Sent
                End If
            Case PLPriceLockStatus.Sent
                MessageBox.Show("This price lock has already been sent.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
        End Select

        If newStatus IsNot Nothing Then
            Try
                _dataAccess.UpdatePriceLockStatus(_priceLock.PriceLockID, newStatus, Environment.UserName)
                _priceLock.Status = newStatus
                cboStatus.Text = newStatus
                UpdateControlStates()
            Catch ex As Exception
                MessageBox.Show($"Error updating status: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Private Sub AddComponent()
        Using frm As New frmComponentPricingEdit(Nothing, _priceLock, _dataAccess)
            If frm.ShowDialog() = DialogResult.OK Then
                LoadComponentPricing()
            End If
        End Using
    End Sub

    Private Sub EditSelectedComponent()
        If dgvComponents.SelectedRows.Count = 0 Then Return
        Dim index = dgvComponents.SelectedRows(0).Index
        If index < 0 OrElse index >= _componentPricing.Count Then Return

        Dim comp = _componentPricing(index)
        Dim componentPricingID = comp.ComponentPricingID ' Store the ID for re-selection

        Using frm As New frmComponentPricingEdit(comp, _priceLock, _dataAccess)
            If frm.ShowDialog() = DialogResult.OK Then
                LoadComponentPricing() ' This reloads from database

                ' ENHANCED: Reselect the edited row
                For i = 0 To dgvComponents.Rows.Count - 1
                    If dgvComponents.Rows(i).Cells("ComponentPricingID").Value IsNot Nothing AndAlso
                   CInt(dgvComponents.Rows(i).Cells("ComponentPricingID").Value) = componentPricingID Then
                        dgvComponents.ClearSelection()
                        dgvComponents.Rows(i).Selected = True
                        dgvComponents.FirstDisplayedScrollingRowIndex = i
                        Exit For
                    End If
                Next
            End If
        End Using
    End Sub

    Private Sub DeleteSelectedComponent()
        If dgvComponents.SelectedRows.Count = 0 Then Return
        Dim index = dgvComponents.SelectedRows(0).Index
        If index < 0 OrElse index >= _componentPricing.Count Then Return

        Dim comp = _componentPricing(index)

        If MessageBox.Show($"Delete component pricing for {comp.FullDescription}?",
            "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = DialogResult.Yes Then
            Try
                _dataAccess.DeleteComponentPricing(comp.ComponentPricingID)
                LoadComponentPricing()
            Catch ex As Exception
                MessageBox.Show($"Error deleting: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Private Sub EditSelectedMaterial()
        If dgvMaterials.SelectedRows.Count = 0 Then Return
        Dim index = dgvMaterials.SelectedRows(0).Index
        If index < 0 OrElse index >= _materialPricing.Count Then Return

        Dim mat = _materialPricing(index)

        Using frm As New frmMaterialPricingEdit(mat, _priceLock, _dataAccess)
            If frm.ShowDialog() = DialogResult.OK Then
                LoadMaterialPricing()
            End If
        End Using
    End Sub

    Private Sub ImportMitekCsv()
        Using frm As New frmMitekImport(_priceLock, _dataAccess)
            If frm.ShowDialog() = DialogResult.OK Then
                LoadComponentPricing()
            End If
        End Using
    End Sub

    Private Sub UpdateControlStates()
        Dim canEdit = _priceLock.CanEdit

        dtpLockDate.Enabled = canEdit
        txtLockName.Enabled = canEdit
        nudBaseMgmtMargin.Enabled = canEdit
        nudAdjustedMargin.Enabled = canEdit
        nudOptionMargin.Enabled = canEdit
        btnAddComponent.Enabled = canEdit
        btnEditComponent.Enabled = canEdit
        btnDeleteComponent.Enabled = canEdit
        btnImportMitek.Enabled = canEdit
        btnEditMaterial.Enabled = canEdit
        btnSave.Enabled = canEdit
        btnAddMaterial.Enabled = canEdit
        btnImportRL.Enabled = canEdit

        ' Update status button text
        Select Case _priceLock.Status
            Case PLPriceLockStatus.Draft
                btnChangeStatus.Text = "Submit"
            Case PLPriceLockStatus.Pending
                btnChangeStatus.Text = "Approve"
            Case PLPriceLockStatus.Approved
                btnChangeStatus.Text = "Mark Sent"
            Case PLPriceLockStatus.Sent
                btnChangeStatus.Text = "Sent"
                btnChangeStatus.Enabled = False
        End Select
    End Sub

    ' ADD these methods in the "CRUD Operations" region (after EditSelectedMaterial, around line 670)

    Private Sub AddMaterial()
        Using frm As New frmMaterialPricingAdd(_priceLock, _dataAccess)
            If frm.ShowDialog() = DialogResult.OK Then
                LoadMaterialPricing()
            End If
        End Using
    End Sub

    Private Sub ImportRandomLengths()
        Using frm As New frmRandomLengthsImport(_priceLock, _dataAccess)
            If frm.ShowDialog() = DialogResult.OK Then
                LoadMaterialPricing()
            End If
        End Using
    End Sub

#End Region

End Class